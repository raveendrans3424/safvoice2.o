# SafeVoice — Anonymous College Complaint System

A working, self-contained full-stack app for reporting and managing harassment,
bullying, ragging, and cyberbullying complaints on campus — with **true anonymity**,
not just "confidentiality."

## What changed from the original prototype

The original schema linked every complaint to a `student_id` → `users` table with
a real name. That's *confidential*, not anonymous — a database breach or a curious
admin could still see who filed what. This version removes that link entirely:

- No student accounts, no login, no identity fields on the complaint form.
- A complaint is only ever reachable through a random tracking code
  (e.g. `SV-7K2XQRT9`) shown once at submission.
- If a student loses their code, there is intentionally no recovery path —
  building one would require storing identity, which defeats the point.
- Admins/committee members log in separately and can never see who filed a
  complaint, only its content.

## Running it locally

**Requirements:** Node.js 18+

```bash
cd backend
npm install
cp .env.example .env
npm start
```

Open **http://localhost:5000** in your browser. That's it — one server serves
both the API and the frontend, and the SQLite database file
(`backend/safevoice.db`) is created automatically on first run, complete with
seed departments and a default admin login.

### Default staff login (created on first boot)

- Email: `admin@college.edu`
- Password: `ChangeMe123!`

**Change this password immediately** after first login (or edit `.env` before
the first run to set your own). There's a `PUT /api/auth/change-password`
endpoint for this — a "change password" UI button is a good next addition.

## What's implemented

- Anonymous complaint submission (no identity ever stored)
- Token-based status tracking + two-way anonymous messaging with the committee
- Evidence file upload (type/size validated, 10MB limit)
- Admin dashboard: complaint list with filters, per-complaint detail view,
  private admin notes (never shown to students), status timeline updates,
  CSV export, analytics (resolution rate, category/status breakdown, monthly trend)
- Full audit logging of every admin action (who viewed/changed what, when, from what IP)
- Role-based access: `admin` vs `superadmin` (only superadmins see the audit log
  and can create new admin accounts)
- Rate limiting on login, submission, and tracking-code lookup to resist brute-force/spam
- Security basics: bcrypt password hashing, JWT sessions, Helmet headers, input validation

## What's still needed before a real production launch

This is a strong working MVP, not yet a hardened production deployment. Before
real students' real complaints go through it:

1. **Move off SQLite to PostgreSQL** for real concurrent multi-admin usage (the
   schema is simple enough to port directly — the SQL types map closely).
2. **Move file uploads to S3/Cloudflare R2** instead of local disk — safer, and
   required if you ever deploy across multiple server instances.
3. **HTTPS is mandatory** — deploy behind a reverse proxy (Nginx/Caddy) or a
   platform (Render/Railway) that terminates SSL for you. Never run this over
   plain HTTP with real complaint data.
4. **Multi-tenancy** — if you're selling this to multiple colleges, add a
   `colleges` table and a `college_id` column to every table, plus middleware
   that scopes every query to the logged-in admin's college.
5. **Legal basics** — a Terms of Service and Privacy Policy that accurately
   describes what "anonymous" means in this system, reviewed against your
   state's/UGC's anti-ragging and POSH compliance requirements.
6. **Automated backups** of the database — losing this data mid-investigation
   would be a serious problem for whoever's case is open.
7. **A "create admin" UI** — right now it's an API endpoint only
   (`POST /api/admin/admins`, superadmin-only); wire it into the dashboard
   before handing this to real staff.

## Project structure

```
safevoice/
├── backend/
│   ├── src/
│   │   ├── config/db.js          # SQLite schema + seed data
│   │   ├── controllers/          # Business logic
│   │   ├── middleware/           # Auth, rate limiting, file upload
│   │   ├── routes/                # Route definitions
│   │   ├── utils/                # Tracking token gen, audit logging
│   │   └── index.js               # Express server entry point
│   ├── public/index.html          # Full frontend (single file, no build step)
│   ├── package.json
│   └── .env.example
└── README.md
```
