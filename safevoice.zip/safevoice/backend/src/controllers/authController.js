const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query } = require('../config/pgdb');
const { logAudit } = require('../utils/audit');

async function login(req, res) {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const { rows } = await query('SELECT * FROM admins WHERE email = $1 AND is_active = TRUE', [email.toLowerCase().trim()]);
  const admin = rows[0];

  if (!admin) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const valid = bcrypt.compareSync(password, admin.password_hash);
  if (!valid) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const token = jwt.sign(
    { type: 'admin', id: admin.id, role: admin.role, email: admin.email },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
  );

  await logAudit(admin.id, 'Admin logged in', req);

  res.json({
    token,
    admin: {
      id: admin.id,
      email: admin.email,
      full_name: admin.full_name,
      role: admin.role,
      department_id: admin.department_id
    }
  });
}

async function me(req, res) {
  const { rows } = await query('SELECT id, email, full_name, role, department_id FROM admins WHERE id = $1', [req.admin.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Admin not found.' });
  res.json({ admin: rows[0] });
}

async function changePassword(req, res) {
  const { current_password, new_password } = req.body;
  if (!current_password || !new_password || new_password.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters.' });
  }

  const { rows } = await query('SELECT * FROM admins WHERE id = $1', [req.admin.id]);
  const admin = rows[0];
  const valid = bcrypt.compareSync(current_password, admin.password_hash);
  if (!valid) return res.status(401).json({ error: 'Current password is incorrect.' });

  const newHash = bcrypt.hashSync(new_password, 10);
  await query('UPDATE admins SET password_hash = $1 WHERE id = $2', [newHash, admin.id]);
  await logAudit(admin.id, 'Admin changed password', req);

  res.json({ message: 'Password updated successfully.' });
}

module.exports = { login, me, changePassword };
