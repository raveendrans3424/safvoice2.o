const bcrypt = require('bcryptjs');
const { query } = require('../config/pgdb');
const { logAudit } = require('../utils/audit');
const { getEvidenceSignedUrl } = require('../utils/s3signed');

const VALID_STATUSES = ['Submitted', 'Under Review', 'Investigation Started', 'Action Taken', 'Resolved', 'Closed'];

async function listComplaints(req, res) {
  const { search, category, status, department_id, date_start, date_end, page = 1, limit = 20 } = req.query;

  const conditions = ['1=1'];
  const params = [];

  if (search) {
    params.push(`%${search}%`, `%${search}%`);
    conditions.push(`(title ILIKE $${params.length - 1} OR description ILIKE $${params.length})`);
  }
  if (category) { params.push(category); conditions.push(`category = $${params.length}`); }
  if (status) { params.push(status); conditions.push(`status = $${params.length}`); }
  if (department_id) { params.push(department_id); conditions.push(`department_id = $${params.length}`); }
  if (date_start) { params.push(date_start); conditions.push(`created_at >= $${params.length}`); }
  if (date_end) { params.push(date_end); conditions.push(`created_at <= $${params.length}`); }

  const where = conditions.join(' AND ');
  const offset = (parseInt(page) - 1) * parseInt(limit);

  const listParams = [...params, parseInt(limit), offset];
  const { rows: complaints } = await query(
    `SELECT id, tracking_token, category, title, status, department_id, created_at, updated_at
     FROM complaints WHERE ${where} ORDER BY created_at DESC LIMIT $${listParams.length - 1} OFFSET $${listParams.length}`,
    listParams
  );

  const { rows: countRows } = await query(`SELECT COUNT(*) as total FROM complaints WHERE ${where}`, params);

  await logAudit(req.admin.id, 'Viewed complaints list', req, { filters: req.query });

  res.json({ complaints, total: parseInt(countRows[0].total, 10), page: parseInt(page), limit: parseInt(limit) });
}

async function getComplaintDetail(req, res) {
  const { id } = req.params;
  const { rows } = await query('SELECT * FROM complaints WHERE id = $1', [id]);
  const complaint = rows[0];
  if (!complaint) return res.status(404).json({ error: 'Complaint not found.' });

  const history = (await query(
    `SELECT h.status, h.comment, h.created_at, a.full_name as changed_by
     FROM complaint_status_history h LEFT JOIN admins a ON h.changed_by_admin_id = a.id
     WHERE h.complaint_id = $1 ORDER BY h.created_at ASC`, [id]
  )).rows;

  const messages = (await query(
    'SELECT sender_role, message_text, is_read, created_at FROM messages WHERE complaint_id = $1 ORDER BY created_at ASC',
    [id]
  )).rows;

  const evidenceRows = (await query(
    'SELECT id, file_name, file_type, file_path, file_size, created_at FROM evidence_files WHERE complaint_id = $1',
    [id]
  )).rows;

  // Generate short-lived signed URLs so admins can view evidence without the S3 bucket being public
  const evidence = await Promise.all(evidenceRows.map(async (e) => ({
    id: e.id, file_name: e.file_name, file_type: e.file_type, file_size: e.file_size, created_at: e.created_at,
    view_url: await getEvidenceSignedUrl(e.file_path)
  })));

  const notes = (await query(
    `SELECT n.note_text, n.created_at, a.full_name as admin_name
     FROM admin_notes n JOIN admins a ON n.admin_id = a.id
     WHERE n.complaint_id = $1 ORDER BY n.created_at DESC`, [id]
  )).rows;

  await logAudit(req.admin.id, 'Viewed complaint details', req, { complaint_id: id });

  res.json({ complaint, history, messages, evidence, notes });
}

async function updateStatus(req, res) {
  const { id } = req.params;
  const { status, comment } = req.body;

  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: `Status must be one of: ${VALID_STATUSES.join(', ')}` });
  }

  const { rows } = await query('SELECT id FROM complaints WHERE id = $1', [id]);
  if (!rows[0]) return res.status(404).json({ error: 'Complaint not found.' });

  await query('UPDATE complaints SET status = $1, updated_at = NOW() WHERE id = $2', [status, id]);
  await query(
    'INSERT INTO complaint_status_history (complaint_id, status, comment, changed_by_admin_id) VALUES ($1,$2,$3,$4)',
    [id, status, comment || null, req.admin.id]
  );

  await logAudit(req.admin.id, 'Updated complaint status', req, { complaint_id: id, new_status: status });

  res.json({ message: 'Status updated.' });
}

async function addNote(req, res) {
  const { id } = req.params;
  const { note_text } = req.body;

  if (!note_text || !note_text.trim()) {
    return res.status(400).json({ error: 'Note text cannot be empty.' });
  }

  const { rows } = await query('SELECT id FROM complaints WHERE id = $1', [id]);
  if (!rows[0]) return res.status(404).json({ error: 'Complaint not found.' });

  await query('INSERT INTO admin_notes (complaint_id, admin_id, note_text) VALUES ($1,$2,$3)', [id, req.admin.id, note_text.trim()]);
  await logAudit(req.admin.id, 'Added private note', req, { complaint_id: id });

  res.status(201).json({ message: 'Note added.' });
}

async function sendMessageToComplainant(req, res) {
  const { id } = req.params;
  const { message_text } = req.body;

  if (!message_text || !message_text.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const { rows } = await query('SELECT id FROM complaints WHERE id = $1', [id]);
  if (!rows[0]) return res.status(404).json({ error: 'Complaint not found.' });

  await query("INSERT INTO messages (complaint_id, sender_role, message_text) VALUES ($1,'admin',$2)", [id, message_text.trim()]);
  await logAudit(req.admin.id, 'Sent message to complainant', req, { complaint_id: id });

  res.status(201).json({ message: 'Message sent.' });
}

async function getAnalytics(req, res) {
  const total = parseInt((await query('SELECT COUNT(*) as c FROM complaints')).rows[0].c, 10);
  const byStatus = (await query('SELECT status, COUNT(*) as count FROM complaints GROUP BY status')).rows;
  const byCategory = (await query('SELECT category, COUNT(*) as count FROM complaints GROUP BY category')).rows;

  const monthlyTrend = (await query(`
    SELECT to_char(created_at, 'YYYY-MM') as month, COUNT(*) as count
    FROM complaints GROUP BY month ORDER BY month DESC LIMIT 12
  `)).rows;

  const resolved = parseInt((await query(
    "SELECT COUNT(*) as c FROM complaints WHERE status IN ('Resolved','Closed')"
  )).rows[0].c, 10);

  const avgRow = (await query(`
    SELECT AVG(EXTRACT(EPOCH FROM (updated_at - created_at)) / 86400.0) as avg_days
    FROM complaints WHERE status IN ('Resolved','Closed')
  `)).rows[0];

  res.json({
    total_complaints: total,
    resolved_count: resolved,
    resolution_rate: total ? Math.round((resolved / total) * 100) : 0,
    avg_resolution_days: avgRow.avg_days ? Math.round(parseFloat(avgRow.avg_days) * 10) / 10 : null,
    by_status: byStatus,
    by_category: byCategory,
    monthly_trend: monthlyTrend.reverse()
  });
}

async function getAuditLogs(req, res) {
  const { rows } = await query(`
    SELECT l.action, l.ip_address, l.details, l.created_at, a.full_name as admin_name, a.email as admin_email
    FROM audit_logs l LEFT JOIN admins a ON l.admin_id = a.id
    ORDER BY l.created_at DESC LIMIT 200
  `);
  res.json({ logs: rows });
}

async function exportCsv(req, res) {
  const { rows } = await query(
    'SELECT id, category, title, status, department_id, created_at, updated_at FROM complaints ORDER BY created_at DESC'
  );

  const header = 'ID,Category,Title,Status,Department ID,Created At,Updated At\n';
  const body = rows.map(c =>
    [c.id, c.category, `"${c.title.replace(/"/g, '""')}"`, c.status, c.department_id || '', c.created_at, c.updated_at].join(',')
  ).join('\n');

  await logAudit(req.admin.id, 'Exported complaints CSV', req);

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="safevoice_complaints_export.csv"');
  res.send(header + body);
}

async function listAdmins(req, res) {
  const { rows } = await query('SELECT id, email, full_name, role, department_id, is_active, created_at FROM admins');
  res.json({ admins: rows });
}

async function createAdmin(req, res) {
  const { email, password, full_name, role, department_id } = req.body;
  if (!email || !password || !full_name) {
    return res.status(400).json({ error: 'Email, password, and full name are required.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  }
  const { rows: existing } = await query('SELECT id FROM admins WHERE email = $1', [email.toLowerCase().trim()]);
  if (existing[0]) return res.status(409).json({ error: 'An admin with this email already exists.' });

  const hash = bcrypt.hashSync(password, 10);
  const { rows } = await query(
    'INSERT INTO admins (email, password_hash, full_name, role, department_id) VALUES ($1,$2,$3,$4,$5) RETURNING id',
    [email.toLowerCase().trim(), hash, full_name, role === 'superadmin' ? 'superadmin' : 'admin', department_id || null]
  );

  await logAudit(req.admin.id, 'Created new admin account', req, { new_admin_email: email });

  res.status(201).json({ message: 'Admin account created.', admin_id: rows[0].id });
}

module.exports = {
  listComplaints, getComplaintDetail, updateStatus, addNote,
  sendMessageToComplainant, getAnalytics, getAuditLogs, exportCsv,
  listAdmins, createAdmin
};
