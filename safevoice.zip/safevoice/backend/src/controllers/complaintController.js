const { query } = require('../config/pgdb');
const { generateTrackingToken, generateComplaintId } = require('../utils/tokens');

const VALID_CATEGORIES = ['Ragging', 'Bullying', 'Cyberbullying', 'Harassment', 'Discrimination', 'Other'];

async function submitComplaint(req, res) {
  const {
    category, title, description, incident_date_time,
    location, accused_name, accused_department,
    witness_details, has_no_evidence, department_id
  } = req.body;

  if (!category || !VALID_CATEGORIES.includes(category)) {
    return res.status(400).json({ error: `Category must be one of: ${VALID_CATEGORIES.join(', ')}` });
  }
  if (!title || title.trim().length < 5 || title.length > 255) {
    return res.status(400).json({ error: 'Title must be between 5 and 255 characters.' });
  }
  if (!description || description.trim().length < 20) {
    return res.status(400).json({ error: 'Please provide a description of at least 20 characters so the committee has enough detail to act on.' });
  }

  let token;
  let attempts = 0;
  let exists = true;
  while (exists && attempts < 5) {
    token = generateTrackingToken();
    const { rows } = await query('SELECT 1 FROM complaints WHERE tracking_token = $1', [token]);
    exists = rows.length > 0;
    attempts++;
  }

  const id = generateComplaintId();

  await query(`
    INSERT INTO complaints
      (id, tracking_token, category, title, description, incident_date_time, location,
       accused_name, accused_department, witness_details, has_no_evidence, department_id, status)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'Submitted')
  `, [
    id, token, category, title.trim(), description.trim(),
    incident_date_time || null, location || null,
    (accused_name && accused_name.trim()) || 'Unknown',
    accused_department || null,
    witness_details || null,
    !!has_no_evidence,
    department_id || null
  ]);

  await query(`
    INSERT INTO complaint_status_history (complaint_id, status, comment)
    VALUES ($1, 'Submitted', 'Complaint submitted by student.')
  `, [id]);

  res.status(201).json({
    message: 'Your complaint has been submitted. Save your tracking code somewhere safe — it is the only way to check on your complaint or add more information later. We cannot recover it if lost.',
    tracking_token: token,
    complaint_id: id
  });
}

async function getComplaintByToken(req, res) {
  const { token } = req.params;
  const { rows } = await query('SELECT * FROM complaints WHERE tracking_token = $1', [token]);
  const complaint = rows[0];

  if (!complaint) {
    return res.status(404).json({ error: 'No complaint found for this tracking code.' });
  }

  const history = (await query(
    'SELECT status, comment, created_at FROM complaint_status_history WHERE complaint_id = $1 ORDER BY created_at ASC',
    [complaint.id]
  )).rows;

  const messages = (await query(
    'SELECT sender_role, message_text, created_at FROM messages WHERE complaint_id = $1 ORDER BY created_at ASC',
    [complaint.id]
  )).rows;

  const evidence = (await query(
    'SELECT id, file_name, file_type, file_size, created_at FROM evidence_files WHERE complaint_id = $1',
    [complaint.id]
  )).rows;

  const { id, ...safeComplaint } = complaint; // never expose internal DB id to the complainant
  res.json({ complaint: safeComplaint, history, messages, evidence });
}

async function sendMessage(req, res) {
  const { token } = req.params;
  const { message_text } = req.body;

  if (!message_text || !message_text.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const { rows } = await query('SELECT id FROM complaints WHERE tracking_token = $1', [token]);
  if (!rows[0]) return res.status(404).json({ error: 'No complaint found for this tracking code.' });

  await query(
    "INSERT INTO messages (complaint_id, sender_role, message_text) VALUES ($1, 'complainant', $2)",
    [rows[0].id, message_text.trim()]
  );

  res.status(201).json({ message: 'Message sent.' });
}

async function uploadEvidence(req, res) {
  const { token } = req.params;
  const { rows } = await query('SELECT id FROM complaints WHERE tracking_token = $1', [token]);
  if (!rows[0]) return res.status(404).json({ error: 'No complaint found for this tracking code.' });

  if (!req.files || req.files.length === 0) {
    return res.status(400).json({ error: 'No files were uploaded.' });
  }

  const inserted = [];
  for (const file of req.files) {
    // file.key is the S3 object key when using multer-s3
    await query(`
      INSERT INTO evidence_files (complaint_id, file_name, file_type, file_path, file_size)
      VALUES ($1,$2,$3,$4,$5)
    `, [rows[0].id, file.originalname, file.mimetype, file.key, file.size]);
    inserted.push({ file_name: file.originalname, size: file.size });
  }

  res.status(201).json({ message: 'Evidence uploaded successfully.', files: inserted });
}

function getCategories(req, res) {
  res.json({ categories: VALID_CATEGORIES });
}

async function getDepartments(req, res) {
  const { rows } = await query('SELECT id, name, code FROM departments ORDER BY name');
  res.json({ departments: rows });
}

module.exports = {
  submitComplaint, getComplaintByToken, sendMessage, uploadEvidence,
  getCategories, getDepartments
};
