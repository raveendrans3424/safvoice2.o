const { query } = require('../config/pgdb');
const { generateCounselingToken, generateCounselingId } = require('../utils/tokens');
const { logAudit } = require('../utils/audit');

const VALID_MODES = ['Phone Call', 'Video Call', 'In-Person'];
const VALID_STATUSES = ['Requested', 'Scheduled', 'Completed', 'Cancelled'];

// ---------- PUBLIC ----------

async function submitRequest(req, res) {
  const { preferred_mode, urgency, preferred_time, message, contact_info } = req.body;

  if (!preferred_mode || !VALID_MODES.includes(preferred_mode)) {
    return res.status(400).json({ error: `Preferred mode must be one of: ${VALID_MODES.join(', ')}` });
  }

  let token;
  let attempts = 0;
  let exists = true;
  while (exists && attempts < 5) {
    token = generateCounselingToken();
    const { rows } = await query('SELECT 1 FROM counseling_requests WHERE request_token = $1', [token]);
    exists = rows.length > 0;
    attempts++;
  }

  const id = generateCounselingId();

  await query(`
    INSERT INTO counseling_requests
      (id, request_token, preferred_mode, urgency, preferred_time, message, contact_info, status)
    VALUES ($1,$2,$3,$4,$5,$6,$7,'Requested')
  `, [
    id, token, preferred_mode,
    urgency === 'Urgent' ? 'Urgent' : 'Normal',
    preferred_time || null,
    message || null,
    // contact_info is entirely optional and typed by the student - never required
    (contact_info && contact_info.trim()) || null
  ]);

  res.status(201).json({
    message: 'Your counseling request has been sent. Save this code to check status or message the counselor — we cannot recover it if lost.',
    request_token: token,
    request_id: id
  });
}

async function getRequestByToken(req, res) {
  const { token } = req.params;
  const { rows } = await query('SELECT * FROM counseling_requests WHERE request_token = $1', [token]);
  const request = rows[0];
  if (!request) return res.status(404).json({ error: 'No counseling request found for this code.' });

  const messages = (await query(
    'SELECT sender_role, message_text, created_at FROM counseling_messages WHERE request_id = $1 ORDER BY created_at ASC',
    [request.id]
  )).rows;

  const { id, ...safe } = request;
  res.json({ request: safe, messages });
}

async function sendMessage(req, res) {
  const { token } = req.params;
  const { message_text } = req.body;
  if (!message_text || !message_text.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const { rows } = await query('SELECT id FROM counseling_requests WHERE request_token = $1', [token]);
  if (!rows[0]) return res.status(404).json({ error: 'No counseling request found for this code.' });

  await query(
    "INSERT INTO counseling_messages (request_id, sender_role, message_text) VALUES ($1,'complainant',$2)",
    [rows[0].id, message_text.trim()]
  );
  res.status(201).json({ message: 'Message sent.' });
}

// ---------- ADMIN ----------

async function listRequests(req, res) {
  const { status, urgency, page = 1, limit = 20 } = req.query;
  const conditions = ['1=1'];
  const params = [];

  if (status) { params.push(status); conditions.push(`status = $${params.length}`); }
  if (urgency) { params.push(urgency); conditions.push(`urgency = $${params.length}`); }

  const where = conditions.join(' AND ');
  const offset = (parseInt(page) - 1) * parseInt(limit);
  const listParams = [...params, parseInt(limit), offset];

  const { rows } = await query(
    `SELECT id, request_token, preferred_mode, urgency, status, scheduled_time, created_at
     FROM counseling_requests WHERE ${where}
     ORDER BY (urgency = 'Urgent') DESC, created_at DESC LIMIT $${listParams.length - 1} OFFSET $${listParams.length}`,
    listParams
  );

  const { rows: countRows } = await query(`SELECT COUNT(*) as total FROM counseling_requests WHERE ${where}`, params);

  await logAudit(req.admin.id, 'Viewed counseling requests list', req);

  res.json({ requests: rows, total: parseInt(countRows[0].total, 10) });
}

async function getRequestDetail(req, res) {
  const { id } = req.params;
  const { rows } = await query('SELECT * FROM counseling_requests WHERE id = $1', [id]);
  const request = rows[0];
  if (!request) return res.status(404).json({ error: 'Counseling request not found.' });

  const messages = (await query(
    'SELECT sender_role, message_text, created_at FROM counseling_messages WHERE request_id = $1 ORDER BY created_at ASC',
    [id]
  )).rows;

  await logAudit(req.admin.id, 'Viewed counseling request details', req, { request_id: id });

  res.json({ request, messages });
}

async function updateRequestStatus(req, res) {
  const { id } = req.params;
  const { status, scheduled_time } = req.body;

  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: `Status must be one of: ${VALID_STATUSES.join(', ')}` });
  }

  const { rows } = await query('SELECT id FROM counseling_requests WHERE id = $1', [id]);
  if (!rows[0]) return res.status(404).json({ error: 'Counseling request not found.' });

  await query(
    'UPDATE counseling_requests SET status = $1, scheduled_time = $2, updated_at = NOW() WHERE id = $3',
    [status, scheduled_time || null, id]
  );

  await logAudit(req.admin.id, 'Updated counseling request status', req, { request_id: id, new_status: status });

  res.json({ message: 'Status updated.' });
}

async function adminSendMessage(req, res) {
  const { id } = req.params;
  const { message_text } = req.body;
  if (!message_text || !message_text.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const { rows } = await query('SELECT id FROM counseling_requests WHERE id = $1', [id]);
  if (!rows[0]) return res.status(404).json({ error: 'Counseling request not found.' });

  await query("INSERT INTO counseling_messages (request_id, sender_role, message_text) VALUES ($1,'admin',$2)", [id, message_text.trim()]);
  await logAudit(req.admin.id, 'Sent message on counseling request', req, { request_id: id });

  res.status(201).json({ message: 'Message sent.' });
}

module.exports = {
  submitRequest, getRequestByToken, sendMessage,
  listRequests, getRequestDetail, updateRequestStatus, adminSendMessage
};
