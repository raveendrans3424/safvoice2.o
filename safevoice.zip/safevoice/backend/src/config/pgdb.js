const { Pool } = require('pg');

// -------------------------------------------------------------------------
// RDS PostgreSQL connection pool.
//
// In AWS, these values come from environment variables injected by
// Elastic Beanstalk / ECS task definition, sourced from Secrets Manager.
// Never hardcode credentials here.
// -------------------------------------------------------------------------
const pool = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT || '5432', 10),
  database: process.env.DB_NAME || 'safevoice',
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  // RDS requires SSL by default on newer parameter groups
  ssl: process.env.DB_SSL === 'false' ? false : { rejectUnauthorized: false },
  max: parseInt(process.env.DB_POOL_MAX || '10', 10),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle Postgres client', err);
});

// Thin wrapper so controllers can keep using db.query(...) the same way
// regardless of driver, and so a single query() call matches how the
// rest of the codebase already expects to call the DB.
async function query(text, params) {
  const start = Date.now();
  const res = await pool.query(text, params);
  if (process.env.NODE_ENV !== 'production') {
    console.log('query', { text, duration: Date.now() - start, rows: res.rowCount });
  }
  return res;
}

module.exports = { pool, query };
