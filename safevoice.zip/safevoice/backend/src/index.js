require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const path = require('path');

// NOTE: Unlike the local SQLite version, the Postgres schema is NOT
// auto-created on boot. Run `node src/db/migrate.js` once against your
// RDS instance (see DEPLOYMENT.md) before starting the app for the first time.

const authRoutes = require('./routes/authRoutes');
const complaintRoutes = require('./routes/complaintRoutes');
const counselingRoutes = require('./routes/counselingRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// ---- Security middleware ----
app.use(helmet({
  contentSecurityPolicy: false // relaxed for the bundled static frontend; tighten if hosting frontend separately
}));
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// ---- API routes ----
app.use('/api/auth', authRoutes);
app.use('/api/complaints', complaintRoutes);
app.use('/api/counseling', counselingRoutes);
app.use('/api/admin', adminRoutes);

app.get('/api/health', async (req, res) => {
  try {
    const { query } = require('./config/pgdb');
    await query('SELECT 1');
    res.json({ status: 'ok', db: 'connected', time: new Date().toISOString() });
  } catch (err) {
    res.status(503).json({ status: 'error', db: 'unreachable', error: err.message });
  }
});

// ---- Serve frontend (static build) ----
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found.' });
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// ---- Error handler (must be last) ----
app.use((err, req, res, next) => {
  console.error(err);
  if (err.message && err.message.includes('File type not allowed')) {
    return res.status(400).json({ error: err.message });
  }
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'File too large. Maximum size is 10MB.' });
  }
  res.status(500).json({ error: 'Something went wrong on our end. Please try again.' });
});

app.listen(PORT, () => {
  console.log(`\n  SafeVoice server running at http://localhost:${PORT}`);
  console.log(`  Admin login: ${process.env.SUPERADMIN_EMAIL || 'admin@college.edu'}\n`);
});
