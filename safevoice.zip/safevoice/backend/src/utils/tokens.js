const crypto = require('crypto');

// Generates a human-typeable, unguessable tracking token like SV-7K2X9QRT
// Excludes ambiguous characters (0/O, 1/I/L) to reduce user entry errors.
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

function generateTrackingToken() {
  let code = '';
  const bytes = crypto.randomBytes(8);
  for (let i = 0; i < 8; i++) {
    code += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return `SV-${code}`;
}

function generateCounselingToken() {
  let code = '';
  const bytes = crypto.randomBytes(8);
  for (let i = 0; i < 8; i++) {
    code += ALPHABET[bytes[i] % ALPHABET.length];
  }
  return `CN-${code}`;
}

function generateComplaintId() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `CMP-${y}${m}${d}-${rand}`;
}

function generateCounselingId() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `CNS-${y}${m}${d}-${rand}`;
}

module.exports = { generateTrackingToken, generateCounselingToken, generateComplaintId, generateCounselingId };
