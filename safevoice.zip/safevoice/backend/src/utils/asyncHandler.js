// Express 4 does not automatically catch rejected promises from async
// route handlers - without this, a DB/S3 error in an async controller
// would crash the request silently (or hang). Wrap every async handler
// with this in the route files.
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

module.exports = asyncHandler;
