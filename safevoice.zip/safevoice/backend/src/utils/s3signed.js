const { S3Client, GetObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

const s3 = new S3Client({ region: process.env.AWS_REGION || 'ap-south-1' });
const BUCKET = process.env.S3_EVIDENCE_BUCKET;

// Generates a short-lived (10 min) signed URL so evidence files stay
// private in S3 but admins can still view them without the bucket
// itself ever being public.
async function getEvidenceSignedUrl(objectKey) {
  const command = new GetObjectCommand({ Bucket: BUCKET, Key: objectKey });
  return getSignedUrl(s3, command, { expiresIn: 600 });
}

module.exports = { getEvidenceSignedUrl };
