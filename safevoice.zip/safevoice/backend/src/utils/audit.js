const { query } = require('../config/pgdb');

async function logAudit(adminId, action, req, details = null) {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
  await query(
    'INSERT INTO audit_logs (admin_id, action, ip_address, details) VALUES ($1, $2, $3, $4)',
    [adminId, action, ip, details ? JSON.stringify(details) : null]
  );
}

module.exports = { logAudit };
