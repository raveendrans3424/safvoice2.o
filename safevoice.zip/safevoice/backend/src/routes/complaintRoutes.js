const express = require('express');
const router = express.Router();
const upload = require('../middleware/uploadS3');
const { submitLimiter, tokenLookupLimiter } = require('../middleware/rateLimiters');
const asyncHandler = require('../utils/asyncHandler');
const {
  submitComplaint, getComplaintByToken, sendMessage, uploadEvidence,
  getCategories, getDepartments
} = require('../controllers/complaintController');

router.get('/categories', getCategories);
router.get('/departments', asyncHandler(getDepartments));
router.post('/', submitLimiter, asyncHandler(submitComplaint));
router.get('/:token', tokenLookupLimiter, asyncHandler(getComplaintByToken));
router.post('/:token/messages', tokenLookupLimiter, asyncHandler(sendMessage));
router.post('/:token/evidence', tokenLookupLimiter, upload.array('files', 5), asyncHandler(uploadEvidence));

module.exports = router;
