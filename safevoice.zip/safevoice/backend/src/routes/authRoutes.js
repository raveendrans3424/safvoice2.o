const express = require('express');
const router = express.Router();
const { login, me, changePassword } = require('../controllers/authController');
const { requireAdmin } = require('../middleware/auth');
const { loginLimiter } = require('../middleware/rateLimiters');
const asyncHandler = require('../utils/asyncHandler');

router.post('/login', loginLimiter, asyncHandler(login));
router.get('/me', requireAdmin, asyncHandler(me));
router.put('/change-password', requireAdmin, asyncHandler(changePassword));

module.exports = router;
