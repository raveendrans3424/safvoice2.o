const express = require('express');
const router = express.Router();
const { submitLimiter, tokenLookupLimiter } = require('../middleware/rateLimiters');
const asyncHandler = require('../utils/asyncHandler');
const { submitRequest, getRequestByToken, sendMessage } = require('../controllers/counselingController');

router.post('/', submitLimiter, asyncHandler(submitRequest));
router.get('/:token', tokenLookupLimiter, asyncHandler(getRequestByToken));
router.post('/:token/messages', tokenLookupLimiter, asyncHandler(sendMessage));

module.exports = router;
