const express = require('express');
const router = express.Router();
const { requireAdmin, requireSuperadmin } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const {
  listComplaints, getComplaintDetail, updateStatus, addNote,
  sendMessageToComplainant, getAnalytics, getAuditLogs, exportCsv,
  listAdmins, createAdmin
} = require('../controllers/adminController');
const {
  listRequests, getRequestDetail, updateRequestStatus, adminSendMessage
} = require('../controllers/counselingController');

router.use(requireAdmin);

router.get('/complaints', asyncHandler(listComplaints));
router.get('/complaints/:id', asyncHandler(getComplaintDetail));
router.put('/complaints/:id/status', asyncHandler(updateStatus));
router.post('/complaints/:id/notes', asyncHandler(addNote));
router.post('/complaints/:id/messages', asyncHandler(sendMessageToComplainant));
router.get('/analytics', asyncHandler(getAnalytics));
router.get('/audit-logs', requireSuperadmin, asyncHandler(getAuditLogs));
router.get('/export', asyncHandler(exportCsv));
router.get('/admins', requireSuperadmin, asyncHandler(listAdmins));
router.post('/admins', requireSuperadmin, asyncHandler(createAdmin));

router.get('/counseling', asyncHandler(listRequests));
router.get('/counseling/:id', asyncHandler(getRequestDetail));
router.put('/counseling/:id/status', asyncHandler(updateRequestStatus));
router.post('/counseling/:id/messages', asyncHandler(adminSendMessage));

module.exports = router;
