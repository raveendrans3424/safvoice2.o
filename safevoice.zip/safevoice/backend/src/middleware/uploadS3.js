const multer = require('multer');
const multerS3 = require('multer-s3');
const { S3Client } = require('@aws-sdk/client-s3');
const crypto = require('crypto');
const path = require('path');

// In AWS, the SDK picks up credentials automatically from the ECS task
// role / EB instance role - never hardcode access keys here.
const s3 = new S3Client({ region: process.env.AWS_REGION || 'ap-south-1' });

const BUCKET = process.env.S3_EVIDENCE_BUCKET;

const ALLOWED_MIME_TYPES = new Set([
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
  'video/mp4',
  'audio/mpeg',
  'audio/mp3'
]);

const fileFilter = (req, file, cb) => {
  if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
    return cb(new Error('File type not allowed. Accepted: JPG, PNG, WEBP, PDF, MP4, MP3.'));
  }
  cb(null, true);
};

const upload = multer({
  storage: multerS3({
    s3,
    bucket: BUCKET,
    serverSideEncryption: 'aws:kms', // uses the bucket's default KMS key
    metadata: (req, file, cb) => cb(null, { fieldName: file.fieldname }),
    key: (req, file, cb) => {
      const randomName = crypto.randomBytes(16).toString('hex');
      const ext = path.extname(file.originalname).toLowerCase();
      // Prefix by complaint token so objects are easy to locate/audit,
      // but the token itself reveals nothing since it's not linked to identity
      const token = (req.params.token || 'unlinked').toLowerCase();
      cb(null, `evidence/${token}/${randomName}${ext}`);
    }
  }),
  fileFilter,
  limits: {
    fileSize: parseInt(process.env.MAX_UPLOAD_SIZE || '10485760', 10),
    files: 5
  }
});

module.exports = upload;
