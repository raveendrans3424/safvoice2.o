const rateLimit = require('express-rate-limit');

// Complaint submission: generous but prevents spam flooding
const submitLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  message: { error: 'Too many submissions from this network. Please try again later.' },
  standardHeaders: true,
  legacyHeaders: false
});

// Admin login: strict, to slow down brute-force password guessing
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  message: { error: 'Too many login attempts. Please wait 15 minutes and try again.' },
  standardHeaders: true,
  legacyHeaders: false
});

// Token lookup (tracking status): moderate, tokens could otherwise be brute-forced
const tokenLookupLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 20,
  message: { error: 'Too many lookup attempts. Please wait a few minutes and try again.' },
  standardHeaders: true,
  legacyHeaders: false
});

module.exports = { submitLimiter, loginLimiter, tokenLookupLimiter };
