-- =========================================================================
-- SafeVoice - PostgreSQL schema for AWS RDS deployment
-- Run this once against your RDS instance before first app boot.
-- Anonymity design preserved: complaints have NO identity foreign key,
-- only an unguessable tracking_token.
-- =========================================================================

CREATE TABLE IF NOT EXISTS departments (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(50) NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admins (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL CHECK (role IN ('admin', 'superadmin')) DEFAULT 'admin',
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS complaints (
  id VARCHAR(50) PRIMARY KEY,
  tracking_token VARCHAR(50) NOT NULL UNIQUE,
  category VARCHAR(100) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  incident_date_time TIMESTAMPTZ,
  location VARCHAR(255),
  accused_name VARCHAR(255) DEFAULT 'Unknown',
  accused_department VARCHAR(255),
  witness_details TEXT,
  has_no_evidence BOOLEAN DEFAULT FALSE,
  status VARCHAR(50) NOT NULL DEFAULT 'Submitted'
    CHECK (status IN ('Submitted','Under Review','Investigation Started','Action Taken','Resolved','Closed')),
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS complaint_status_history (
  id SERIAL PRIMARY KEY,
  complaint_id VARCHAR(50) NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  status VARCHAR(50) NOT NULL,
  comment TEXT,
  changed_by_admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- file_path here stores the S3 object key, not a local disk path
CREATE TABLE IF NOT EXISTS evidence_files (
  id SERIAL PRIMARY KEY,
  complaint_id VARCHAR(50) NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  file_name VARCHAR(255) NOT NULL,
  file_type VARCHAR(100) NOT NULL,
  file_path VARCHAR(500) NOT NULL,  -- S3 object key
  file_size INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  complaint_id VARCHAR(50) NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  sender_role VARCHAR(20) NOT NULL CHECK (sender_role IN ('complainant','admin')),
  message_text TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_notes (
  id SERIAL PRIMARY KEY,
  complaint_id VARCHAR(50) NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  admin_id INTEGER NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  note_text TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id SERIAL PRIMARY KEY,
  admin_id INTEGER REFERENCES admins(id) ON DELETE SET NULL,
  action VARCHAR(255) NOT NULL,
  ip_address VARCHAR(45),
  details TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -------------------------------------------------------------------------
-- Counseling requests: same anonymity model as complaints - no identity
-- FK, only a random unlinkable request_token. Contact info is OPTIONAL
-- and typed in by the student themselves only if they choose to share it.
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS counseling_requests (
  id VARCHAR(50) PRIMARY KEY,
  request_token VARCHAR(50) NOT NULL UNIQUE,
  preferred_mode VARCHAR(30) NOT NULL CHECK (preferred_mode IN ('Phone Call','Video Call','In-Person')),
  urgency VARCHAR(20) NOT NULL DEFAULT 'Normal' CHECK (urgency IN ('Normal','Urgent')),
  preferred_time TEXT,
  message TEXT,
  contact_info TEXT, -- optional, student-provided only, never required
  status VARCHAR(30) NOT NULL DEFAULT 'Requested'
    CHECK (status IN ('Requested','Scheduled','Completed','Cancelled')),
  scheduled_time TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS counseling_messages (
  id SERIAL PRIMARY KEY,
  request_id VARCHAR(50) NOT NULL REFERENCES counseling_requests(id) ON DELETE CASCADE,
  sender_role VARCHAR(20) NOT NULL CHECK (sender_role IN ('complainant','admin')),
  message_text TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_counseling_token ON counseling_requests(request_token);
CREATE INDEX IF NOT EXISTS idx_counseling_status ON counseling_requests(status);
CREATE INDEX IF NOT EXISTS idx_counseling_messages_request ON counseling_messages(request_id);

CREATE INDEX IF NOT EXISTS idx_complaints_status ON complaints(status);
CREATE INDEX IF NOT EXISTS idx_complaints_category ON complaints(category);
CREATE INDEX IF NOT EXISTS idx_complaints_token ON complaints(tracking_token);
CREATE INDEX IF NOT EXISTS idx_history_complaint ON complaint_status_history(complaint_id);
CREATE INDEX IF NOT EXISTS idx_evidence_complaint ON evidence_files(complaint_id);
CREATE INDEX IF NOT EXISTS idx_messages_complaint ON messages(complaint_id);
CREATE INDEX IF NOT EXISTS idx_notes_complaint ON admin_notes(complaint_id);

-- Seed departments (safe to re-run, ON CONFLICT skips duplicates)
INSERT INTO departments (name, code) VALUES
('Computer Science & Engineering', 'CSE'),
('Electronics & Communication', 'ECE'),
('Mechanical Engineering', 'ME'),
('Civil Engineering', 'CE'),
('Business Administration', 'MBA'),
('General / Not Sure', 'GEN')
ON CONFLICT (code) DO NOTHING;
