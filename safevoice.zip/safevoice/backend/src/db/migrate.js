// Run this once after the RDS instance is reachable, to create the schema
// and seed the first superadmin account. Usage: node src/db/migrate.js
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { pool } = require('../config/pgdb');

async function migrate() {
  console.log('Connecting to', process.env.DB_HOST, '...');
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  await pool.query(schema);
  console.log('Schema applied.');

  const { rows } = await pool.query('SELECT COUNT(*) as c FROM admins');
  if (parseInt(rows[0].c, 10) === 0) {
    const email = process.env.SUPERADMIN_EMAIL || 'admin@college.edu';
    const password = process.env.SUPERADMIN_PASSWORD;
    const name = process.env.SUPERADMIN_NAME || 'System Administrator';
    if (!password) {
      console.error('SUPERADMIN_PASSWORD is not set in the environment. Refusing to create an admin with no password.');
      process.exit(1);
    }
    const hash = bcrypt.hashSync(password, 10);
    await pool.query(
      'INSERT INTO admins (email, password_hash, full_name, role) VALUES ($1, $2, $3, $4)',
      [email, hash, name, 'superadmin']
    );
    console.log(`Superadmin created: ${email}`);
  } else {
    console.log('Admins already exist, skipping superadmin seed.');
  }

  await pool.end();
  console.log('Done.');
}

migrate().catch(err => {
  console.error('Migration failed:', err);
  process.exit(1);
});
