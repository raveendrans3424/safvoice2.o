# SafeVoice — AWS Free Tier Deployment Guide

This is a **cost-minimized** deployment path for launching your pilot with
zero (or near-zero) AWS spend during your first 12 months. It intentionally
skips services that aren't free-tier eligible (ALB, NAT Gateway, Secrets
Manager) in favor of a simpler, single-instance architecture that's genuinely
fine for a single-college pilot.

**Expected cost: $0–2/month** for the first 12 months (only real cost is
optionally a domain name, ~$10-12/year, and possibly a Route53 hosted zone at
$0.50/month if you want a custom domain from day one).

> ⚠️ Set a **Billing Alarm** before you do anything else (Step 0). This is
> non-negotiable — free tier limits are easy to accidentally exceed (e.g.
> leaving a second EC2 instance running), and you want to know the moment
> that happens, not at month-end.

---

## Architecture for this guide

```
                    Internet
                        │
                  Route53 (optional)
                        │
              EC2 t3.micro (public subnet)
              - Node.js app runs here directly
              - Security Group = your only firewall
              - ACM cert + Nginx reverse proxy for HTTPS
                        │
              RDS PostgreSQL db.t3.micro
              (private-ish: no public access,
               but same public subnet's route table —
               security group is what actually blocks access)
                        │
                  S3 bucket (evidence files)
```

No NAT Gateway, no ALB, no Secrets Manager. When you outgrow this (multiple
colleges, need for zero-downtime deploys, need for auto-scaling), migrate to
the ECS Fargate path from the previous guide — nothing here is wasted work,
the same RDS instance and S3 bucket carry forward.

---

## Step 0 — Billing alarm (do this first, takes 3 minutes)

1. AWS Console → search **"Billing"** → **Billing Preferences** → check
   "Receive Free Tier Usage Alerts" and "Receive Billing Alerts" → enter your
   email.
2. Go to **CloudWatch → Alarms → Billing** → Create Alarm → set threshold to
   **$5** → send to an SNS topic that emails you.

This means if anything ever goes off free tier, you get an email within hours,
not a surprise bill next month.

---

## Step 1 — Use the default VPC (simplest, zero cost)

Every AWS account has a default VPC with public subnets already set up and an
Internet Gateway attached. You don't need to build a custom VPC for this —
that adds complexity with zero benefit at pilot scale.

```bash
aws ec2 describe-vpcs --filters "Name=is-default,Values=true" \
  --query 'Vpcs[0].VpcId' --output text
```
Save this as `<VPC_ID>`. Then get its public subnets:
```bash
aws ec2 describe-subnets --filters "Name=vpc-id,Values=<VPC_ID>" \
  --query 'Subnets[*].[SubnetId,AvailabilityZone]' --output table
```
Pick any one subnet ID — save as `<SUBNET_ID>`.

---

## Step 2 — Security groups

### App security group (for EC2)
```bash
aws ec2 create-security-group \
  --group-name safevoice-app-sg \
  --description "SafeVoice app server" \
  --vpc-id <VPC_ID>
# save the returned GroupId as APP_SG_ID

# Allow HTTP (80) and HTTPS (443) from anywhere
aws ec2 authorize-security-group-ingress --group-id <APP_SG_ID> --protocol tcp --port 80 --cidr 0.0.0.0/0
aws ec2 authorize-security-group-ingress --group-id <APP_SG_ID> --protocol tcp --port 443 --cidr 0.0.0.0/0

# Allow SSH ONLY from your own IP (find yours: curl ifconfig.me)
aws ec2 authorize-security-group-ingress --group-id <APP_SG_ID> --protocol tcp --port 22 --cidr <YOUR_IP>/32
```

### DB security group (for RDS)
```bash
aws ec2 create-security-group \
  --group-name safevoice-db-sg \
  --description "SafeVoice RDS - app access only" \
  --vpc-id <VPC_ID>
# save as DB_SG_ID

# Allow Postgres (5432) ONLY from the app security group - this is what
# actually keeps your database private, not subnet placement
aws ec2 authorize-security-group-ingress \
  --group-id <DB_SG_ID> --protocol tcp --port 5432 --source-group <APP_SG_ID>
```

---

## Step 3 — RDS PostgreSQL (free tier)

```bash
aws rds create-db-instance \
  --db-instance-identifier safevoice-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --engine-version 16.3 \
  --master-username safevoice_admin \
  --master-user-password '<CHOOSE_A_STRONG_PASSWORD>' \
  --allocated-storage 20 \
  --storage-type gp2 \
  --vpc-security-group-ids <DB_SG_ID> \
  --no-publicly-accessible \
  --backup-retention-period 7 \
  --db-name safevoice
```
Notes:
- `db.t3.micro` + `20` GB `gp2` storage = exactly the free tier envelope.
  Don't bump these up while on free tier, or you'll incur charges.
- `--no-publicly-accessible` is correct even without a private subnet — the
  security group is your real protection, this flag just removes the public
  IP so it's not internet-facing at all.

Wait for it (~5-10 min):
```bash
aws rds wait db-instance-available --db-instance-identifier safevoice-db
aws rds describe-db-instances --db-instance-identifier safevoice-db \
  --query 'DBInstances[0].Endpoint.Address' --output text
```
Save this endpoint as `<DB_HOST>`.

---

## Step 4 — S3 bucket for evidence (free tier)

```bash
aws s3api create-bucket \
  --bucket safevoice-evidence-<pick-a-unique-suffix> \
  --region ap-south-1 \
  --create-bucket-configuration LocationConstraint=ap-south-1

aws s3api put-public-access-block \
  --bucket safevoice-evidence-<your-suffix> \
  --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true

# Default AWS-managed encryption is free (SSE-S3) - skip the customer KMS
# key from the production guide for now, since KMS has a small per-request
# cost. Free default encryption is still solid protection for a pilot.
aws s3api put-bucket-encryption \
  --bucket safevoice-evidence-<your-suffix> \
  --server-side-encryption-configuration '{
    "Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]
  }'
```

---

## Step 5 — IAM role for EC2 (so it can reach S3 without hardcoded keys)

```bash
aws iam create-role --role-name safevoice-ec2-role \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [{"Effect": "Allow", "Principal": {"Service": "ec2.amazonaws.com"}, "Action": "sts:AssumeRole"}]
  }'

aws iam put-role-policy --role-name safevoice-ec2-role \
  --policy-name safevoice-s3-access \
  --policy-document '{
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Action": ["s3:PutObject", "s3:GetObject"],
      "Resource": "arn:aws:s3:::safevoice-evidence-<your-suffix>/*"
    }]
  }'

aws iam create-instance-profile --instance-profile-name safevoice-ec2-profile
aws iam add-role-to-instance-profile --instance-profile-name safevoice-ec2-profile --role-name safevoice-ec2-role
```

---

## Step 6 — Launch the EC2 instance (free tier)

### Create a key pair (for SSH access)
```bash
aws ec2 create-key-pair --key-name safevoice-key --query 'KeyMaterial' --output text > safevoice-key.pem
chmod 400 safevoice-key.pem
```

### Find the latest Amazon Linux 2023 AMI
```bash
aws ec2 describe-images \
  --owners amazon \
  --filters "Name=name,Values=al2023-ami-*-x86_64" "Name=state,Values=available" \
  --query 'sort_by(Images, &CreationDate)[-1].ImageId' --output text
```
Save as `<AMI_ID>`.

### Launch it
```bash
aws ec2 run-instances \
  --image-id <AMI_ID> \
  --instance-type t3.micro \
  --key-name safevoice-key \
  --subnet-id <SUBNET_ID> \
  --security-group-ids <APP_SG_ID> \
  --iam-instance-profile Name=safevoice-ec2-profile \
  --associate-public-ip-address \
  --tag-specifications 'ResourceType=instance,Tags=[{Key=Name,Value=safevoice-app}]'
```
Get its public IP once running:
```bash
aws ec2 describe-instances --filters "Name=tag:Name,Values=safevoice-app" \
  --query 'Reservations[0].Instances[0].PublicIpAddress' --output text
```
Save as `<APP_IP>`.

**Important:** `t3.micro` (not `t2.micro`) is free tier in most regions now —
double check under Billing → Free Tier in your specific account/region, as
eligible instance types occasionally shift.

---

## Step 7 — SSH in and set up the server

```bash
ssh -i safevoice-key.pem ec2-user@<APP_IP>
```

Once inside:
```bash
# Install Node.js 20
curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
sudo yum install -y nodejs git nginx

# Install PM2 to keep the app running and auto-restart on crash/reboot
sudo npm install -g pm2
```

---

## Step 8 — Deploy your code

From your local machine (not the EC2 instance), upload the project:
```bash
scp -i safevoice-key.pem -r safevoice/backend ec2-user@<APP_IP>:~/safevoice-backend
```

Back on the EC2 instance:
```bash
cd ~/safevoice-backend
npm install --omit=dev
```

Create the production `.env` (no Secrets Manager for now — this file lives
only on the instance, never committed to git):
```bash
cat > .env << 'EOF'
PORT=5000
NODE_ENV=production
JWT_SECRET=<generate with: node -e "console.log(require('crypto').randomBytes(48).toString('hex'))">
JWT_EXPIRES_IN=8h
DB_HOST=<your RDS endpoint>
DB_PORT=5432
DB_NAME=safevoice
DB_USER=safevoice_admin
DB_PASSWORD=<your RDS password>
DB_SSL=true
AWS_REGION=ap-south-1
S3_EVIDENCE_BUCKET=safevoice-evidence-<your-suffix>
MAX_UPLOAD_SIZE=10485760
EOF
chmod 600 .env
```

### Run the DB migration (creates tables + your first admin)
```bash
SUPERADMIN_EMAIL=admin@yourcollege.edu \
SUPERADMIN_PASSWORD='<ChooseAStrongPassword>' \
SUPERADMIN_NAME='Your Name' \
node src/db/migrate.js
```
You should see `Schema applied.` and `Superadmin created: ...`.

### Start the app with PM2
```bash
pm2 start src/index.js --name safevoice
pm2 save
pm2 startup   # follow the printed instructions to enable auto-start on reboot
```

Test directly (before Nginx is set up):
```bash
curl http://localhost:5000/api/health
# should return {"status":"ok","db":"connected",...}
```

---

## Step 9 — Nginx reverse proxy + HTTPS

Even on a single EC2 instance, don't expose Node directly on port 443 — put
Nginx in front. It's free, handles TLS termination cleanly, and lets you add
things like gzip/caching later without touching app code.

### If you have a domain
Point an A record at `<APP_IP>` in your domain registrar's DNS (or Route53 if
you bought the domain through AWS).

### Install a free TLS cert via Let's Encrypt (Certbot)
```bash
sudo yum install -y python3 python3-pip
sudo pip3 install certbot certbot-nginx
```

### Configure Nginx
```bash
sudo tee /etc/nginx/conf.d/safevoice.conf << 'EOF'
server {
    listen 80;
    server_name complaints.yourcollege.edu;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF
sudo systemctl enable nginx
sudo systemctl start nginx
```

### Get the certificate (auto-configures Nginx for HTTPS + redirect)
```bash
sudo certbot --nginx -d complaints.yourcollege.edu
```
Certbot auto-renews via a systemd timer it installs — nothing more to do.

**No domain yet?** Skip this step for now and access the app over
`http://<APP_IP>` directly (fine for internal pilot testing with your
management, not for real students — get a domain before real launch; a
`.college` or normal `.com`/`.in` domain is ~$10-12/year from Route53,
Namecheap, or GoDaddy).

---

## Step 10 — Final checks

```bash
# From your own machine, not the EC2 instance:
curl https://complaints.yourcollege.edu/api/health
```
Then open it in a browser, submit a test complaint, log in as your seeded
admin, and confirm the full flow works exactly like it did in local testing.

---

## What you're consciously trading away at this stage (and when to fix it)

| Gap | Risk | Fix when |
|---|---|---|
| Single EC2 instance, no auto-scaling/HA | If the instance reboots or fails, app is down until you notice | Once you have real daily usage — move to the ECS Fargate path |
| No WAF/CloudFront | No edge-level rate limiting/bot protection (your app-level rate limiter still works) | Before public multi-college launch |
| `.env` file on disk, no Secrets Manager | Fine for one trusted admin (you) SSH-ing in; don't share SSH access widely | Once you have a team, or before scaling past one college |
| No Multi-AZ RDS | If the single RDS instance has an issue, brief downtime until AWS recovers it (backups still protect the data) | When revenue justifies ~$15/month extra for Multi-AZ |
| Manual deploys via `scp` | Fine solo; becomes error-prone with a team | Set up GitHub Actions once you're not the only one shipping changes |

None of this is "wrong" for a pilot — it's the correct trade-off for $0-2/month
while you prove the product with your first college. Everything here (RDS
data, S3 bucket, app code) carries forward unchanged when you're ready to
harden it.

---

## Quick command reference (save these values as you go)

```
VPC_ID=
SUBNET_ID=
APP_SG_ID=
DB_SG_ID=
DB_HOST=
APP_IP=
S3_BUCKET=safevoice-evidence-<your-suffix>
```
