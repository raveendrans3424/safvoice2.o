# SafeVoice — AWS Deployment Guide

This walks through deploying SafeVoice on AWS end to end: networking, database,
storage, secrets, compute, and TLS. It assumes AWS CLI v2 is installed and
configured (`aws configure`) with an IAM user/role that has sufficient
permissions (Administrator for first setup is fine; scope down later).

Two paths are covered:
- **Path A — Elastic Beanstalk**: fastest to stand up, good for your college pilot.
- **Path B — ECS Fargate**: production-grade, for when you're serving multiple colleges.

Do Path A first. Path B is a migration, not a rewrite — same container, same RDS, same S3 bucket.

Region used throughout: `ap-south-1` (Mumbai) — swap if you're deploying elsewhere.

---

## Part 0 — Networking foundation (shared by both paths)

You need a VPC with public subnets (for the load balancer) and private subnets
(for RDS and your app compute, so neither is directly internet-reachable).

### Option 1 — use the AWS default VPC (fastest, fine for a pilot)
Every AWS account has a default VPC with public subnets already. Skip to Part 1
and use the default VPC's subnets. You'll still put RDS in a DB subnet group
scoped to "no public access."

### Option 2 — purpose-built VPC (recommended before Path B)
```bash
aws ec2 create-vpc --cidr-block 10.0.0.0/16 --tag-specifications \
  'ResourceType=vpc,Tags=[{Key=Name,Value=safevoice-vpc}]'

# Note the VpcId returned, then create 2 public + 2 private subnets across 2 AZs
aws ec2 create-subnet --vpc-id <VPC_ID> --cidr-block 10.0.1.0/24 --availability-zone ap-south-1a --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=safevoice-public-1a}]'
aws ec2 create-subnet --vpc-id <VPC_ID> --cidr-block 10.0.2.0/24 --availability-zone ap-south-1b --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=safevoice-public-1b}]'
aws ec2 create-subnet --vpc-id <VPC_ID> --cidr-block 10.0.11.0/24 --availability-zone ap-south-1a --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=safevoice-private-1a}]'
aws ec2 create-subnet --vpc-id <VPC_ID> --cidr-block 10.0.12.0/24 --availability-zone ap-south-1b --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=safevoice-private-1b}]'
```
Then attach an Internet Gateway to the VPC, route the public subnets to it, and
set up a NAT Gateway in a public subnet so private-subnet resources (RDS,
Fargate tasks) can reach out (e.g. to pull npm packages at build time, or call
S3) without being reachable *from* the internet.

This part is genuinely easier done once in the **VPC console wizard**
("Create VPC" → "VPC and more") than via 15 CLI calls — it auto-wires route
tables, IGW, and NAT for you. I'd suggest doing it there and using the CLI/CDK
for everything after.

---

## Part 1 — S3 bucket for evidence files

```bash
aws s3api create-bucket \
  --bucket safevoice-evidence-<your-unique-suffix> \
  --region ap-south-1 \
  --create-bucket-configuration LocationConstraint=ap-south-1

# Block all public access — this bucket must never be public
aws s3api put-public-access-block \
  --bucket safevoice-evidence-<your-unique-suffix> \
  --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true

# Enable default encryption with a customer-managed KMS key (not the AWS-managed default)
aws kms create-key --description "SafeVoice evidence encryption key" \
  --tags TagKey=Project,TagValue=SafeVoice
# note the KeyId from the output, then:
aws s3api put-bucket-encryption \
  --bucket safevoice-evidence-<your-unique-suffix> \
  --server-side-encryption-configuration '{
    "Rules": [{
      "ApplyServerSideEncryptionByDefault": {
        "SSEAlgorithm": "aws:kms",
        "KMSMasterKeyID": "<KEY_ID>"
      }
    }]
  }'

# Enable versioning — protects against accidental overwrite/delete of evidence
aws s3api put-bucket-versioning \
  --bucket safevoice-evidence-<your-unique-suffix> \
  --versioning-configuration Status=Enabled
```

Why a customer-managed KMS key instead of default SSE-S3: it lets you see
every decrypt/encrypt call in **CloudTrail**, tied to a specific principal —
useful if you ever need to prove, in an actual disciplinary hearing, exactly
who accessed a piece of evidence and when.

---

## Part 2 — RDS PostgreSQL

### Create a DB subnet group (private subnets only)
```bash
aws rds create-db-subnet-group \
  --db-subnet-group-name safevoice-db-subnets \
  --db-subnet-group-description "Private subnets for SafeVoice RDS" \
  --subnet-ids <PRIVATE_SUBNET_1> <PRIVATE_SUBNET_2>
```

### Create a security group for RDS
```bash
aws ec2 create-security-group \
  --group-name safevoice-rds-sg \
  --description "Allow Postgres from app tier only" \
  --vpc-id <VPC_ID>
# note the returned GroupId as RDS_SG_ID — you'll authorize the app's SG into this after Part 3/4
```

### Create the instance
```bash
aws rds create-db-instance \
  --db-instance-identifier safevoice-db \
  --db-instance-class db.t4g.micro \
  --engine postgres \
  --engine-version 16.3 \
  --master-username safevoice_admin \
  --master-user-password '<STRONG_PASSWORD_HERE>' \
  --allocated-storage 20 \
  --storage-type gp3 \
  --db-subnet-group-name safevoice-db-subnets \
  --vpc-security-group-ids <RDS_SG_ID> \
  --no-publicly-accessible \
  --backup-retention-period 7 \
  --storage-encrypted \
  --db-name safevoice
```
For the pilot, `db.t4g.micro` + single-AZ is enough. When you're production-ready
for multiple colleges, add `--multi-az` and bump the instance class.

**Wait for it to become available** (5-10 min):
```bash
aws rds wait db-instance-available --db-instance-identifier safevoice-db
aws rds describe-db-instances --db-instance-identifier safevoice-db \
  --query 'DBInstances[0].Endpoint.Address' --output text
```
Save that endpoint — it's your `DB_HOST`.

### Run the schema migration
From a machine that can reach the private subnet (a bastion host, a Cloud9
instance in the VPC, or temporarily via an SSM port-forward session — do NOT
make RDS publicly accessible just to run this):

```bash
cd backend
DB_HOST=<rds-endpoint> DB_USER=safevoice_admin DB_PASSWORD=<password> \
DB_NAME=safevoice DB_SSL=true \
SUPERADMIN_EMAIL=admin@yourcollege.edu SUPERADMIN_PASSWORD='<StrongPass>' \
node src/db/migrate.js
```
This creates all tables and seeds your first superadmin account — I tested
this script directly against a fresh Postgres instance and confirmed the
schema, indexes, and seed logic all apply cleanly with zero errors.

**Best practice:** after this, create a separate, less-privileged DB user for
the app itself (`safevoice_app`) with grants only on the tables it needs, and
use that as `DB_USER` in the running app — keep `safevoice_admin` for
migrations only.

---

## Part 3 — Secrets Manager

Store everything sensitive here instead of plaintext env files:

```bash
aws secretsmanager create-secret \
  --name safevoice/prod/app-secrets \
  --secret-string '{
    "JWT_SECRET": "<paste output of: node -e \"console.log(require(\"crypto\").randomBytes(48).toString(\"hex\"))\">",
    "DB_HOST": "<rds-endpoint>",
    "DB_PORT": "5432",
    "DB_NAME": "safevoice",
    "DB_USER": "safevoice_app",
    "DB_PASSWORD": "<password>",
    "S3_EVIDENCE_BUCKET": "safevoice-evidence-<your-unique-suffix>"
  }'
```

---

## Part 4 — Path A: Elastic Beanstalk (do this first)

### 4.1 Install the EB CLI
```bash
pip install awsebcli --break-system-packages   # or use pipx
```

### 4.2 Initialize
```bash
cd backend
eb init safevoice --region ap-south-1 --platform "Node.js 20"
```

### 4.3 Create the environment
```bash
eb create safevoice-pilot \
  --instance-type t3.micro \
  --vpc.id <VPC_ID> \
  --vpc.ec2subnets <PUBLIC_SUBNET_1>,<PUBLIC_SUBNET_2> \
  --vpc.elbsubnets <PUBLIC_SUBNET_1>,<PUBLIC_SUBNET_2> \
  --vpc.securitygroups <APP_SG_ID> \
  --single
```
`--single` skips the load balancer for the cheapest possible pilot setup (one
instance, no HA). Drop that flag once you want a proper ALB in front.

### 4.4 Authorize the app's security group into RDS
```bash
aws ec2 authorize-security-group-ingress \
  --group-id <RDS_SG_ID> \
  --protocol tcp --port 5432 \
  --source-group <APP_SG_ID>
```
This is the step people forget — without it, your app will time out connecting
to RDS even though both are "in the same VPC."

### 4.5 Set environment variables
Pull values from Secrets Manager and set them as EB environment properties
(EB injects these as real env vars into the Node process):
```bash
eb setenv \
  NODE_ENV=production \
  JWT_SECRET="<from secrets manager>" \
  DB_HOST="<rds-endpoint>" \
  DB_PORT=5432 \
  DB_NAME=safevoice \
  DB_USER=safevoice_app \
  DB_PASSWORD="<password>" \
  DB_SSL=true \
  AWS_REGION=ap-south-1 \
  S3_EVIDENCE_BUCKET=safevoice-evidence-<your-unique-suffix>
```
For real production, reference Secrets Manager directly via an EB `.ebextensions`
config instead of plaintext `eb setenv` — plaintext env vars are visible to
anyone with EB console read access.

### 4.6 Attach an IAM instance profile with S3 access
EB creates a default instance role (`aws-elasticbeanstalk-ec2-role`). Attach an
inline policy scoped to just your bucket:
```bash
aws iam put-role-policy \
  --role-name aws-elasticbeanstalk-ec2-role \
  --policy-name safevoice-s3-access \
  --policy-document '{
    "Version": "2012-10-17",
    "Statement": [{
      "Effect": "Allow",
      "Action": ["s3:PutObject","s3:GetObject"],
      "Resource": "arn:aws:s3:::safevoice-evidence-<your-unique-suffix>/*"
    }, {
      "Effect": "Allow",
      "Action": ["kms:Decrypt","kms:GenerateDataKey"],
      "Resource": "<your KMS key ARN>"
    }]
  }'
```

### 4.7 Deploy
```bash
eb deploy
eb open
```

### 4.8 Attach TLS (ACM + Route53)
```bash
aws acm request-certificate \
  --domain-name complaints.yourcollege.edu \
  --validation-method DNS
```
Add the returned CNAME validation record in Route53 (or your DNS provider),
wait for `ISSUED` status, then attach the cert to your EB environment's load
balancer listener via the EB console (Configuration → Load Balancer → add
HTTPS listener → select the ACM cert) — this is genuinely easier through the
console than CLI for a one-time setup.

At this point you have a working pilot: `https://complaints.yourcollege.edu`
serving the real app, backed by RDS and S3, ready for your college to use.

---

## Part 5 — Path B: ECS Fargate (production, multi-college scale)

Move to this once Path A is proven and you're onboarding more colleges.

### 5.1 Containerize the app

Add this `Dockerfile` to `backend/`:
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY . .
EXPOSE 5000
CMD ["node", "src/index.js"]
```

Build and push to ECR:
```bash
aws ecr create-repository --repository-name safevoice-backend

aws ecr get-login-password --region ap-south-1 | \
  docker login --username AWS --password-stdin <ACCOUNT_ID>.dkr.ecr.ap-south-1.amazonaws.com

docker build -t safevoice-backend .
docker tag safevoice-backend:latest <ACCOUNT_ID>.dkr.ecr.ap-south-1.amazonaws.com/safevoice-backend:latest
docker push <ACCOUNT_ID>.dkr.ecr.ap-south-1.amazonaws.com/safevoice-backend:latest
```

### 5.2 ECS cluster
```bash
aws ecs create-cluster --cluster-name safevoice-cluster
```

### 5.3 Task execution role + task role
- **Execution role**: lets ECS pull the image and read secrets — attach
  `AmazonECSTaskExecutionRolePolicy` plus a policy allowing
  `secretsmanager:GetSecretValue` on your `safevoice/prod/app-secrets` secret.
- **Task role**: what your *app code* can do at runtime — attach a policy
  scoped only to `s3:GetObject`/`PutObject` on your bucket and
  `kms:Decrypt`/`GenerateDataKey` on your key. This is the least-privilege
  boundary — the app should never have broader S3 or account permissions than
  this.

### 5.4 Task definition (JSON, register via CLI)
```json
{
  "family": "safevoice-backend",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "executionRoleArn": "<execution role ARN>",
  "taskRoleArn": "<task role ARN>",
  "containerDefinitions": [{
    "name": "safevoice-backend",
    "image": "<ACCOUNT_ID>.dkr.ecr.ap-south-1.amazonaws.com/safevoice-backend:latest",
    "portMappings": [{ "containerPort": 5000 }],
    "secrets": [
      { "name": "JWT_SECRET", "valueFrom": "<secret ARN>:JWT_SECRET::" },
      { "name": "DB_HOST", "valueFrom": "<secret ARN>:DB_HOST::" },
      { "name": "DB_PASSWORD", "valueFrom": "<secret ARN>:DB_PASSWORD::" }
    ],
    "environment": [
      { "name": "NODE_ENV", "value": "production" },
      { "name": "DB_PORT", "value": "5432" },
      { "name": "DB_NAME", "value": "safevoice" },
      { "name": "DB_USER", "value": "safevoice_app" },
      { "name": "AWS_REGION", "value": "ap-south-1" },
      { "name": "S3_EVIDENCE_BUCKET", "value": "safevoice-evidence-<your-unique-suffix>" }
    ],
    "logConfiguration": {
      "logDriver": "awslogs",
      "options": {
        "awslogs-group": "/ecs/safevoice-backend",
        "awslogs-region": "ap-south-1",
        "awslogs-stream-prefix": "app"
      }
    }
  }]
}
```
```bash
aws logs create-log-group --log-group-name /ecs/safevoice-backend
aws ecs register-task-definition --cli-input-json file://task-def.json
```

### 5.5 ALB + target group
```bash
aws elbv2 create-load-balancer --name safevoice-alb \
  --subnets <PUBLIC_SUBNET_1> <PUBLIC_SUBNET_2> \
  --security-groups <ALB_SG_ID>

aws elbv2 create-target-group --name safevoice-tg \
  --protocol HTTP --port 5000 --vpc-id <VPC_ID> --target-type ip \
  --health-check-path /api/health
```
Add an HTTPS listener on port 443 using your ACM cert, forwarding to this
target group. Add an HTTP→HTTPS redirect listener on port 80.

### 5.6 ECS service (auto-scaled, private subnets)
```bash
aws ecs create-service \
  --cluster safevoice-cluster \
  --service-name safevoice-service \
  --task-definition safevoice-backend \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[<PRIVATE_SUBNET_1>,<PRIVATE_SUBNET_2>],securityGroups=[<APP_SG_ID>],assignPublicIp=DISABLED}" \
  --load-balancers "targetGroupArn=<TG_ARN>,containerName=safevoice-backend,containerPort=5000"
```
Then set up **Application Auto Scaling** on the service (target tracking on
ECS service CPU%, min 2 / max 6 tasks — 2 minimum so you always have
cross-AZ redundancy).

### 5.7 CloudFront + WAF (edge protection)
```bash
aws wafv2 create-web-acl \
  --name safevoice-waf --scope CLOUDFRONT --region us-east-1 \
  --default-action Allow={} \
  --visibility-config SampledRequestsEnabled=true,CloudWatchMetricsEnabled=true,MetricName=safevoiceWaf \
  --rules '[{"Name":"RateLimit","Priority":1,"Action":{"Block":{}},"Statement":{"RateBasedStatement":{"Limit":2000,"AggregateKeyType":"IP"}},"VisibilityConfig":{"SampledRequestsEnabled":true,"CloudWatchMetricsEnabled":true,"MetricName":"RateLimit"}}]'
```
Then create a CloudFront distribution with your ALB as the origin, attach this
WAF Web ACL, and point your Route53 record at the CloudFront distribution
instead of the ALB directly. This gives you edge-level rate limiting on top of
your app's own rate limiter — meaningful defense in depth given this app will
attract targeted abuse attempts by its nature.

### 5.8 CI/CD (GitHub Actions)
```yaml
# .github/workflows/deploy.yml
name: Deploy to ECS
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: <GitHub OIDC role ARN>
          aws-region: ap-south-1
      - uses: aws-actions/amazon-ecr-login@v2
        id: ecr
      - run: |
          docker build -t $ECR_REGISTRY/safevoice-backend:${{ github.sha }} backend/
          docker push $ECR_REGISTRY/safevoice-backend:${{ github.sha }}
        env:
          ECR_REGISTRY: ${{ steps.ecr.outputs.registry }}
      - run: |
          aws ecs update-service --cluster safevoice-cluster \
            --service safevoice-service --force-new-deployment
```
Use an **OIDC role**, not long-lived access keys, for GitHub Actions to assume
into AWS — avoids storing AWS credentials as GitHub secrets entirely.

---

## Part 6 — Operational checklist before go-live

- [ ] RDS automated backups enabled (done by default above, `--backup-retention-period 7`) — verify with `aws rds describe-db-instances`
- [ ] S3 versioning + lifecycle rule (e.g. move to Glacier after 1 year, never auto-delete evidence tied to open cases)
- [ ] CloudWatch alarms: RDS CPU/storage, ECS task health, ALB 5xx rate — wire to an SNS topic emailing you
- [ ] CloudTrail enabled account-wide, logs to a separate S3 bucket with object lock (tamper-evident audit trail, separate from your app's own `audit_logs` table)
- [ ] Rotate the seeded superadmin password immediately via `PUT /api/auth/change-password`
- [ ] Confirm `DB_SSL=true` is actually being enforced (test that a non-TLS connection to RDS is rejected)
- [ ] Run a basic penetration/abuse test against your own rate limiters before launch (submit spam, brute-force login) to confirm the AWS WAF + app-level limiter combo actually holds
- [ ] Terms of Service + Privacy Policy live and linked from the homepage, accurately describing the anonymity model
- [ ] A documented incident-response step: what happens if S3/RDS access logs show unusual admin activity (ties back to your `audit_logs` table)

---

## Cost estimate (rough, ap-south-1, monthly)

**Path A (pilot):** RDS t4g.micro (~$13) + EB t3.micro (~$8) + S3/data transfer (~$2) + Route53 (~$1) ≈ **$25–30/month**

**Path B (production, 2 Fargate tasks):** Fargate 2×(0.5vCPU/1GB) (~$30) + RDS Multi-AZ t4g.small (~$55) + ALB (~$20) + CloudFront+WAF (~$10-20) + NAT Gateway (~$35) ≈ **$150–180/month**, scaling with usage from there.
